pybtex-docutils
===============

|imagegithub| |imagecodecov|

A docutils backend for pybtex.

* Download: https://pypi.org/project/pybtex-docutils/#files

* Documentation: https://pybtex-docutils.readthedocs.io/

* Development: http://github.com/mcmtroffaes/pybtex-docutils/

.. |imagegithub| image:: https://github.com/mcmtroffaes/pybtex-docutils/actions/workflows/python-package.yml/badge.svg
    :target: https://github.com/mcmtroffaes/pybtex-docutils/actions/workflows/python-package.yml
    :alt: github-ci

.. |imagecodecov| image:: https://codecov.io/gh/mcmtroffaes/pybtex-docutils/branch/develop/graph/badge.svg
    :target: https://codecov.io/gh/mcmtroffaes/pybtex-docutils
    :alt: codecov
