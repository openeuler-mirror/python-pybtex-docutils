Getting Started
===============

Overview
--------

.. include:: ../README.rst

Installation
------------

.. include:: ../INSTALL.rst
