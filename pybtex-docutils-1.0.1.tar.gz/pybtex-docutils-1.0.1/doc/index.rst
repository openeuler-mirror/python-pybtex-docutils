Welcome to pybtex-docutils's documentation!
===========================================

:Release: |release|
:Date:    |today|

Contents
--------

.. toctree::
   :maxdepth: 2


   quickstart
   api
   changes
   license

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

