License
=======

.. include:: ../LICENSE.rst

