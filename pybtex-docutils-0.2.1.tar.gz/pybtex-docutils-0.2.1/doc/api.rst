.. automodule:: pybtex_docutils
