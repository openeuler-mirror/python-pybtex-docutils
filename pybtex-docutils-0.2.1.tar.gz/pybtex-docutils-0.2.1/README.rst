A docutils backend for pybtex.

* Download: http://pypi.python.org/pypi/pybtex-docutils/#downloads

* Documentation: http://pybtex-docutils.readthedocs.org/

* Development: http://github.com/mcmtroffaes/pybtex-docutils/ |imagetravis| |imagecoveralls|

.. |imagetravis| image:: https://travis-ci.org/mcmtroffaes/pybtex-docutils.png?branch=develop
       :target: https://travis-ci.org/mcmtroffaes/pybtex-docutils
       :alt: travis-ci

.. |imagecoveralls| image:: https://coveralls.io/repos/mcmtroffaes/pybtex-docutils/badge.png?branch=develop
       :target: https://coveralls.io/r/mcmtroffaes/pybtex-docutils?branch=develop
       :alt: coveralls.io
